package Data;

public class DataSource {
    public static final String userName = "18827040216";
    public static final String passWord = "123456";
    public static final String url = "http://retailop.yijiupi.com";
}
