# AndroidPos
安卓端的POS自动化脚本
